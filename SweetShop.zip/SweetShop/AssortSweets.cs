﻿namespace SweetShop
{
    public class AssortSweets
    {
        public string ID_Assort { get; set; }
        public string Name_Sweet { get; set; }
        public int ID_Group { get; set; }
        public string Recipe { get; set; }
        public double Weight { get; set; }
        public double PricePerSwet { get; set; }
    }
}
