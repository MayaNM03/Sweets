﻿namespace SweetShop
{
    public class GroupOfSweets 
    {
        public int ID_Group { get; set; }
        public string Name_Group { get; set; }
    }
}
